package main;

import javafx.application.Application;
import javafx.stage.Stage;
import backend.GUIelements.;

public class Main {
	
	
	
	public class GUIelements extends Application{
	    public static void main(String[] args) {
	        launch(args);
	    }
	    
	  //Phil's code for login
	    
	    @Override
		public void start(Stage primaryStage) throws Exception {
	    	
	 
	
	
	
	
	

}
