package sarah;

import javafx.application.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.input.DataFormat;
import javafx.stage.Stage;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import sarah.ReadCSV;
import sarah.SaveSession;


	public class Test extends Application{
		public static void main(String[] args){
			launch (args);
			}
		
		
		public static void showStats(Stage primaryStage, String fileName) {
			

			
			Scene scene = GenericBackground.createBackground("%");
			DisplayStats.makeMenu (fileName, scene, primaryStage);
			GenericBackground.drawBackground(primaryStage, scene);
	 		
			
			
			
			SaveSession.endSession (primaryStage, fileName);
			
			
			
		}


		@Override
		public void start(Stage primaryStage) throws Exception {
			
			showStats(primaryStage, "data.csv");

			

			
		}	
	}

	
	

