package sarah;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Border;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import jxl.Workbook;
import jxl.write.DateFormat;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import paolo.Topic;
import sarah.GenericBackground;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;

import com.opencsv.CSVReader;

import becca.Questions;

//import com.opencsv.CSVReader;

import sarah.ReadCSV;
import sarah.SaveSession;
import sarah.StartSession;
import javafx.beans.binding.DoubleBinding;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class GUIelements extends Application{

	
	    public static void main(String[] args) {
	        launch(args);
	    }
	    	
	    //String to contain all the event details
	    static String[] sessionDetails = new String[5];	
			
		
	    //Method to retrieve event details with GUI
	    public static void SessionDetailsGUI(Stage PrimaryStage) throws FileNotFoundException, IOException{
				
	        Topic topic0 = new Topic();
	        Topic topic1 = new Topic(); 
	        Topic topic2 = new Topic();
	        Topic topic3 = new Topic();
	        Topic topic4 = new Topic();
	        
	        ArrayList<Topic> topics = getTopics(topic0, topic1, topic2, topic3, topic4);
	        
			Scene scene = GenericBackground.createBackground("?");
			Group root = new Group();
			
			Rectangle background = new Rectangle(650,550);
			background.setX(400);
			background.setY(250);
			background.setArcHeight(15);
			background.setArcWidth(15);
			background.setFill(Color.rgb(0, 30, 60, .2));
			
	
			
	        Font labelFont = new Font(16);
	        labelFont.font("sanSerif", FontWeight.BOLD, 20);
						
			final Button button = new Button ("Start Quiz");
			button.setFont(labelFont);
		    final Label notification = new Label ();
		    final TextField schoolName = new TextField("");
		    final TextField date = new TextField("");
		    final TextArea text = new TextArea ("");
		    

		        
		    final ComboBox quizList = new ComboBox();
		    quizList.getItems().addAll(
		       topic0.name,
		       topic1.name,
		       topic2.name,
		       topic3.name,
		       topic4.name  
		    );
		        
		    quizList.setValue("Please select:");
		        
		     final ComboBox yearGroup = new ComboBox();
		     yearGroup.getItems().addAll(
		        "7",
		        "8",
		        "9",
		        "11",
		        "12",
		        "13"
		      );   

		        yearGroup.setValue("Please select:");
		        
		        
		        Label SchoolLabel = new Label("School Name / Event Name: ");
		        SchoolLabel.setFont(labelFont);
		        Label YrGroupLabel = new Label("Year Group: ");
		        YrGroupLabel.setFont(labelFont);
		        Label QuizLabel = new Label("Quiz: ");		        
		        QuizLabel.setFont(labelFont);
		        
		        GridPane grid = new GridPane();
		        grid.setGridLinesVisible(false);
		        grid.setVgap(20);
		        grid.setHgap(10);
		        grid.setPadding(new Insets(400, 250, 250, 450));


		        grid.add((SchoolLabel), 0, 1);
		        grid.setHalignment(SchoolLabel, HPos.RIGHT);
		        grid.add(schoolName, 1, 1);
		        grid.add((YrGroupLabel), 0, 2);
		        grid.setHalignment(YrGroupLabel, HPos.RIGHT);
		        grid.add(yearGroup, 1, 2);
		        grid.add((QuizLabel), 0, 3);            
		        grid.setHalignment(QuizLabel, HPos.RIGHT);
		        grid.add(quizList, 1, 3, 4, 1);
		        grid.add(button, 1, 8);
		        grid.add (notification, 1, 3, 3, 1); 
		        
		        
		        button.setOnAction(new EventHandler<ActionEvent>(){
		        
		            public void handle (ActionEvent event){
		            	
		        		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		        		Date date = new Date();
		        		String sessionDate = dateFormat.format(date);
		            	
		            	GUIelements.sessionDetails[0] = sessionDate;
		            	GUIelements.sessionDetails[1] = schoolName.getText();
		            	GUIelements.sessionDetails[2] = (String) yearGroup.getValue();
		            	GUIelements.sessionDetails[3] = (String) quizList.getValue();
		            	
		            	if (quizList.getValue().equals(topic0.name)){
		            		GUIelements.sessionDetails[4] = "topic0";}
		            		else if (quizList.getValue().equals(topic1.name)){
			            		GUIelements.sessionDetails[4] = "topic1";}
		            		else if (quizList.getValue().equals(topic2.name)){
			            		GUIelements.sessionDetails[4] = "topic2";}
		            		else if (quizList.getValue().equals(topic3.name)){
			            		GUIelements.sessionDetails[4] = "topic3";}
		            		else if (quizList.getValue().equals(topic4.name)){
			            		GUIelements.sessionDetails[4] = "topic4";}
		            	
		            	try {
							ReadCSV.writeToCSV(GUIelements.sessionDetails);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
		            	
		            	quiz(PrimaryStage);
		        }
		            
		        });
		        
		        		
		        ((Group) scene.getRoot()).getChildren().addAll(background,grid);
			 	GenericBackground.drawBackground(PrimaryStage, scene);
				
			 	
			 	
			}
	    
	    
	    
	    
		@Override
		public void start(Stage primaryStage) throws Exception {
			SessionDetailsGUI(primaryStage);
			
			
			
		}


public static ArrayList<Topic> getTopics(Topic topic0, Topic topic1, Topic topic2, Topic topic3, Topic topic4) throws FileNotFoundException, IOException{
    //create topic objects

    
    //create array for topics
    ArrayList<Topic> topics = new ArrayList<Topic>();
    
    //add topic objects to array
    topics.add(topic0);
    topics.add(topic1);
    topics.add(topic2);
    topics.add(topic3);
    topics.add(topic4);
    
    
    //iterate through files
    for (int i = 0; i < 5; i++){
        String file = "topic" + i + ".csv";
        
        CSVReader reader = new CSVReader(new FileReader(file));
        String [] name = reader.readNext();
        topics.get(i).name = name[0];
        
        String [] nextLine;
        while ((nextLine = reader.readNext()) != null) {
        //populate topic array with question objects
            topics.get(i).add(new paolo.Question(
                nextLine[0],
                nextLine[1],
                nextLine[2],
                nextLine[3],
                nextLine[4]
            ));
        }
    }
    return topics;
    
    
}

public static void quiz(Stage PrimaryStage) {


		try {
			//Add filename as argument rather than having hard coded into Questions class
			Questions questions = new Questions();
			String selection;
			int[] stats = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		
			File fileIn = new File("data.csv");
		
			String topic;
		
			try {
		
				Scanner in = new Scanner(fileIn);
				String line = in.nextLine();
		
				String[] parts = line.split(",");
				topic = parts[4];
		
			}
			catch( Exception e ) {
				System.out.println("Problem reading file");
				throw e;
			}
		
			String fileName = topic + ".csv";
		
			//Create question and answer arrays
			String[] allQuestions = questions.question(fileName);
			String[][] allAnswers = questions.answers(fileName);
		
			PrimaryStage.setTitle("Quiz");
		

			  startQuiz(PrimaryStage, allQuestions, allAnswers, stats);
		
		}
		catch( Exception e ) {
			//Do Nothing
		}
		
		}

public static void showQuestion(int i, Stage primaryStage, String[] allQuestions, String[][] allAnswers, int[] stats){

	SaveSession.endSession (primaryStage, "data.csv");
	
	
	Group root = new Group();
	Scene scene = new Scene(root, 1500,900);
	Random rand = new Random(System.currentTimeMillis());
	
	int red = 0;
	int blue = 0;
	int green = 0;	
	int rot = 0;
	
	
	for (int j=0; j<500; j++){
		int x = rand.nextInt((int) scene.getWidth());
		int y = rand.nextInt(200);
		red = rand.nextInt(100);
		green = rand.nextInt(200);
		blue = rand.nextInt(200);	
		rot = rand.nextInt(360);
		
		Text text = new Text(x,y, "quiz");
		Font serifSmall = new Font ("Serif", 18);
		text.setFont(serifSmall);
		text.setFill(Color.rgb(red, blue, green, .4));
		text.setRotate(rot);
		root.getChildren().add(text);
		
	}
	

	Text text2 = new Text(570,120,"Quiz");
	text2.setFont(Font.font("Serif", FontWeight.BOLD, 80));		
	root.getChildren().add(text2);

	FlowPane rootNode = new FlowPane(Orientation.VERTICAL, 0, 10);
	rootNode.setAlignment(Pos.CENTER_LEFT);
	rootNode.setPadding(new Insets(300, 0, 0, 500));
	
	//Scene scene = new Scene(rootNode, 1500,900);

	primaryStage.setScene(scene);

	//Mix up answers
	String correctAnswer = allAnswers[i][0];

	//Code adapted from [insert reference]
	int index;
	String temp;
		Random random = new Random();
		for (int j = allAnswers[i].length - 1; j > 0; j--) {
			index = random.nextInt(j + 1);
			temp = allAnswers[i][index];
			allAnswers[i][index] = allAnswers[i][j];
			allAnswers[i][j] = temp;
		}

		//Determine which is the correct answer
		Label correctLetter = new Label("");

		if (allAnswers[i][0].equals(correctAnswer)) {
			correctLetter.setText("A");
		} 
		else if (allAnswers[i][1].equals(correctAnswer)) {
			correctLetter.setText("B");
		}
		else if (allAnswers[i][2].equals(correctAnswer)) {
			correctLetter.setText("C");
		}
		else {
			correctLetter.setText("D");
		}

		//Display questions and answers
	Label question = new Label(allQuestions[i]);
	Label result = new Label("");
	Label response = new Label("");
	
	RadioButton answer1 = new RadioButton(allAnswers[i][0]);
	RadioButton answer2 = new RadioButton(allAnswers[i][1]);
	RadioButton answer3 = new RadioButton(allAnswers[i][2]);
	RadioButton answer4 = new RadioButton(allAnswers[i][3]);

	ToggleGroup tg = new ToggleGroup();

	answer1.setToggleGroup(tg);
	answer2.setToggleGroup(tg);
	answer3.setToggleGroup(tg);
	answer4.setToggleGroup(tg);

	Button select = new Button("Select");
	select.setPrefWidth(60);

	Button nextBtn = new Button("Next");
	nextBtn.setPrefWidth(60);
	nextBtn.setDisable(true);

	Button exit = new Button("Exit");
	exit.setPrefWidth(60);

	answer1.setOnAction( new EventHandler<ActionEvent>() {
		@Override
			public void handle(ActionEvent ae) {
				response.setText("A");
			}
	});

	answer2.setOnAction( new EventHandler<ActionEvent>() {
		@Override
			public void handle(ActionEvent ae) {
				response.setText("B");
			}
	});

	answer3.setOnAction( new EventHandler<ActionEvent>() {
		@Override
			public void handle(ActionEvent ae) {
				response.setText("C");
			}
	});

	answer4.setOnAction( new EventHandler<ActionEvent>() {
		@Override
			public void handle(ActionEvent ae) {
				response.setText("D");
			}
	});

	select.setOnAction( new EventHandler<ActionEvent>() {
		@Override
			public void handle(ActionEvent ae) {
				if (response.getText().equals(correctLetter.getText())) {
					result.setText("Correct");
		 	 		stats[i] = 1;
				} else {
					result.setText("Incorrect. The answer was " + correctAnswer + ".");
					stats[i] = 2;
				}
				select.setDisable(true);
				nextBtn.setDisable(false);
			}
	});

	nextBtn.setOnAction( new EventHandler<ActionEvent>() {
		@Override
			public void handle(ActionEvent ae) {
				if(i < allQuestions.length-1){
					showQuestion(i+1, primaryStage, allQuestions, allAnswers, stats);
				}else{
					System.out.println("We have reached the last question.");
					startQuiz(primaryStage, allQuestions, allAnswers, stats);

					try {

		             	FileWriter writer = new FileWriter("data.csv", true);
		             	PrintWriter out = new PrintWriter( writer );

		             	out.println( stats[0] + "," + stats[1] + "," + stats[2] + "," + stats[3] + "," + stats[4] + "," + stats[5] + "," + stats[6] + "," + stats[7] + "," + stats[8] + "," + stats[9] );

		             	out.close();
		         	}
		         	catch ( Exception e ) {
		             	System.out.println( e );
		 	        }
				}
			}
	});

	exit.setOnAction( new EventHandler<ActionEvent>() {
		@Override
			public void handle(ActionEvent ae) {
				System.out.println("We have exited before the last question.");
				startQuiz(primaryStage, allQuestions, allAnswers, stats);

				try {

	             	FileWriter writer = new FileWriter("data.csv", true);
	             	PrintWriter out = new PrintWriter( writer );

	             	out.println( stats[0] + "," + stats[1] + "," + stats[2] + "," + stats[3] + "," + stats[4] + "," + stats[5] + "," + stats[6] + "," + stats[7] + "," + stats[8] + "," + stats[9] );

	             	out.close();
	         	}
	         	catch ( Exception e ) {
	             	System.out.println( e );
	 	        }
				
			}
	});

	answer1.fire();

	rootNode.getChildren().addAll(question, answer1, answer2, answer3, answer4, select, result, nextBtn, exit);
	root.getChildren().add(rootNode);
	primaryStage.setScene(scene);
	primaryStage.show();
}


public static void startQuiz( Stage primaryStage, String[] allQuestions, String[][] allAnswers, int[] stats) {
	Group root = new Group();
	Scene scene = new Scene(root, 1500,900);
	Random rand = new Random(System.currentTimeMillis());
	
	int red = 0;
	int blue = 0;
	int green = 0;	
	int rot = 0;
	
	
	for (int j=0; j<500; j++){
		int x = rand.nextInt((int) scene.getWidth());
		int y = rand.nextInt(200);
		red = rand.nextInt(100);
		green = rand.nextInt(200);
		blue = rand.nextInt(200);	
		rot = rand.nextInt(360);
		
		Text text = new Text(x,y, "quiz");
		Font serifSmall = new Font ("Serif", 18);
		text.setFont(serifSmall);
		text.setFill(Color.rgb(red, blue, green, .4));
		text.setRotate(rot);
		root.getChildren().add(text);
		
	}
	

	Text text2 = new Text(570,120,"Quiz");
	text2.setFont(Font.font("Serif", FontWeight.BOLD, 80));		
	root.getChildren().add(text2);

	FlowPane rootNode = new FlowPane(Orientation.VERTICAL, 0, 10);
	rootNode.setAlignment(Pos.CENTER);
	rootNode.setColumnHalignment(HPos.CENTER);
	rootNode.setPadding(new Insets(300, 0, 0, 250));

	//Scene scene = new Scene(rootNode, 1500,900);

	primaryStage.setScene(scene);

	//Display questions and answers
	Label welcome = new Label("Welcome to the Quiz!");
	welcome.setFont(Font.font("Serif", FontWeight.BOLD, 80));

	Button start = new Button("Start");
	start.setPrefWidth(60);

	start.setOnAction( new EventHandler<ActionEvent>() {
		@Override
			public void handle(ActionEvent ae) {
				showQuestion(0, primaryStage, allQuestions, allAnswers, stats);
			}
	});

	rootNode.getChildren().addAll(welcome, start);
	root.getChildren().add(rootNode);
	primaryStage.setScene(scene);
	primaryStage.show();
}





public static void adminOptions( Stage primaryStage) {
	Group root = new Group();
	Scene scene = new Scene(root, 1500,900);
	Random rand = new Random(System.currentTimeMillis());
	
	int red = 0;
	int blue = 0;
	int green = 0;	
	int rot = 0;
	
	
	for (int j=0; j<500; j++){
		int x = rand.nextInt((int) scene.getWidth());
		int y = rand.nextInt(200);
		red = rand.nextInt(100);
		green = rand.nextInt(200);
		blue = rand.nextInt(200);	
		rot = rand.nextInt(360);
		
		Text text = new Text(x,y, "?");
		Font serifSmall = new Font ("Serif", 18);
		text.setFont(serifSmall);
		text.setFill(Color.rgb(red, blue, green, .4));
		text.setRotate(rot);
		root.getChildren().add(text);
		
	}
	
	
	
	Text text2 = new Text(570,120,"Admin");
	text2.setFont(Font.font("Serif", FontWeight.BOLD, 80));		
	root.getChildren().add(text2);

	FlowPane rootNode = new FlowPane(Orientation.VERTICAL, 0, 10);
	rootNode.setAlignment(Pos.CENTER);
	rootNode.setColumnHalignment(HPos.CENTER);
	rootNode.setPadding(new Insets(300, 0, 0, 600));

	//Scene scene = new Scene(rootNode, 1500,900);

	primaryStage.setScene(scene);

	//Display questions and answers
	
	Label adminOptions = new Label("Please choose an option");
	adminOptions.setFont(Font.font("Serif", FontWeight.BOLD, 20));


	Button stats = new Button("View Statistics");
	//stats.setPrefWidth(100);

	stats.setOnAction( new EventHandler<ActionEvent>() {
		@Override
			public void handle(ActionEvent ae) {
				Test.showStats(primaryStage, "data.csv");;
			}
	});
	
	
	Button manageQuiz = new Button("Update Questions");
	//manageQuiz.setPrefWidth(100);

	manageQuiz.setOnAction( new EventHandler<ActionEvent>() {
		@Override
			public void handle(ActionEvent ae) {
			//try {
				System.out.println("arghhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
				//Scene manageScene = phil.StartQuiz.manageQuizScene();
			/*} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			}
		});
	
	Button back = new Button("Start Quiz");

	back.setOnAction( new EventHandler<ActionEvent>() {
		@Override
			public void handle(ActionEvent ae) {
			try {
				SessionDetailsGUI(primaryStage);
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
	});
	
	
	
	

	rootNode.getChildren().addAll(adminOptions, stats, manageQuiz, back);
	root.getChildren().add(rootNode);
	primaryStage.setScene(scene);
	primaryStage.show();
}







}
			
		
			