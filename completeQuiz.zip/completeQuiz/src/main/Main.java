package main;

import javafx.application.Application;

public class Main extends Application {
	
	//Phil
	
	SessionDetailsGUI(primaryStage);
	
	
	
	

}
